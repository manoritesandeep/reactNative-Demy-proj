import { Text } from 'react-native';

function GameOverScreen() {
  return <Text>Game is over!</Text>
}

export default GameOverScreen;